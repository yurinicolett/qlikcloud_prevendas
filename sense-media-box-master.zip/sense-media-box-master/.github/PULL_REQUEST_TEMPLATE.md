Fixes #[issue number].

### Status
```
[ ] Under development
[ ] Waiting for code review
[ ] Waiting for merge
```

### Information
```
[ ] Contains breaking changes
[ ] Contains new API(s)
[ ] Contains documentation
[ ] Contains test
```

### To-do list
```
[ ] [Fix this thing]
[ ] [Fix another thing]
[ ] ...
```
