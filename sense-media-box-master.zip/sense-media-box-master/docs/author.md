**Stefan Walther**
* [qliksite.io](http://qliksite.io)  
* [twitter/waltherstefan](http://twitter.com/waltherstefan)  
* [github.com/stefanwalther](http://github.com/stefanwalther)  
