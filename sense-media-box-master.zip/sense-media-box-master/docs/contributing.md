Pull requests and stars are always welcome. For bugs and feature requests, [please create an issue]({%= bugs.url %}).
The process for contributing is outlined below:

1. Create a fork of the project
2. Work on whatever bug or feature you wish
3. Create a pull request (PR)

I cannot guarantee that I will merge all PRs but I will evaluate them all.