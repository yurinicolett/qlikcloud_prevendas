The idea of this solution is to bundle the usage of several media-types into one Visualization Extension to be used within Qlik Sense.

As of now the following media types are currently supported:

* HTML (+CSS)
* Image from Url
* Image from Library
* Video
* Web sites