it.BulletChart
==============

itelligence BulletChart for Qlik Sense

ZIP it.BullitChart
Copy it to it.BullitChartZIP
ZIP it.BullitChartZIP
Rename it.BullitChartZIP.zip to it.BullitChart.zip
