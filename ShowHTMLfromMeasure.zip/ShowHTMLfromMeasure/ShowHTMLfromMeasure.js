define( ["qlik", "text!./ShowHTMLfromMeasure.ng.html", "css!./ShowHTMLfromMeasure.css"],
	function ( qlik, template ) {
		"use strict";
		return {
			template: template,
			initialProperties: {
				qHyperCubeDef: {
					qDimensions: [],
					qMeasures: [],
					qInitialDataFetch: [{
						qWidth: 2,
						qHeight: 50
					}]
				}
			},
			definition: {
				type: "items",
				component: "accordion",
				items: {
					measures: {
						uses: "measures",
						min: 1,
						max: 1
					},
					settings: {
						uses: "settings",
						items: {
							about: {
								type: "items",
								label: "About",
								items: {
									info_author: {
										type: "string",
										label: "Author",
										ref: "about",
										defaultValue: "FD (fatihdalgic@yahoo.com)"
									},
									info_sample1: {
										type: "string",
										label: "Sample HTML 1",
										ref: "sampleHtml1",
										defaultValue: "='<b>Bold Measure: '&sum(100000) * 5 &'</b>'"+
														"&'<br>Line 2 with num(measure) :'&Num(sum(88888.555),'###,###.#')"+
														"&'<br>Line 3 icon :<span class=\"lui-icon lui-icon--history\"></span>'"+
														"&'<br>Line 4 5vw font :<span style=\"font-size:5vw;\">EXAMPLE</span>'"+

														"&'<div style=\"height:50px;width:100px;background-color:#F3B7A1;padding:10px;\">TEST DIV<div>'"+
														"&'<div style=\"height:50px;width:150px;background-color:#BBF0F8;margin:50px;text-align:center;\">'"+
															"&'TEST DIV with A<br><a href=\"https://www.qlik.com\" target=\"_blank\">qlik.com link</a>'"+
														"&'</div>'"+
														"&'<div style=\"height:100px;width:300px;background-color:#F2F5F5;padding:10px;\">'"+
															"&'TEST DIV with img <br><img src=\"https://qlik.imgix.net/us/-/media/images/qlik/global/qlik-logo-2x.png?h=94&w=308&la=en&hash=91B8028A8CF991CF3864E421063D49298BD58575\">'"+
														"&'</div>'"
									}
								}
							}
						}
					}
				},
			},
			support: {
				snapshot: true,
				export: true,
				exportData: true
			},
			paint: function () {
				//needed for export
				this.$scope.selections = [];
				return qlik.Promise.resolve();
			},
			controller: ["$scope", "$element", function ( $scope ) {
				
				$scope.bindHtml = function () {
				
					return $scope.layout.qHyperCube.qDataPages[0].qMatrix[0][0].qText;
				};
				
				$scope.selections = [];

				$scope.sel = function ( $event ) {
					if ( $event.currentTarget.hasAttribute( "data-row" ) ) {
						var row = parseInt( $event.currentTarget.getAttribute( "data-row" ), 10 ), dim = 0,
							cell = $scope.$parent.layout.qHyperCube.qDataPages[0].qMatrix[row][0];
						if ( cell.qIsNull !== true ) {
							cell.qState = (cell.qState === "S" ? "O" : "S");
							if ( $scope.selections.indexOf( cell.qElemNumber ) === -1 ) {
								$scope.selections.push( cell.qElemNumber );
							} else {
								$scope.selections.splice( $scope.selections.indexOf( cell.qElemNumber ), 1 );
							}
							$scope.selectValues( dim, [cell.qElemNumber], true );
						}
					}
				};
			}]
		};

	} );
